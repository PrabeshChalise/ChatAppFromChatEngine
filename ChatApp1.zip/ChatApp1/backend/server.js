const express = require("express");
const cors = require("cors");
const { default: axios } = require("axios");
const app = express();
app.use(express.json());
app.use(cors({ origin: true }));
app.post("/authenticate", async (req, res) => {
  const { username } = req.body;
  try {
    const r = await axios.put(
      "https://api.chatengine.io/users/",
      { username: username, secret: username, first_name: username },
      { headers: { "private-key": "0c3a147c-06a2-4860-99c5-0fdfdef7de00" } }
    );
    return res.status(r.status).json(r.data);
  } catch (e) {
    if (e.response) {
      return res.status(e.response.status).json(e.response.data);
    } else {
      return res.status(500).json({ error: "Internal Server Error" });
    }
  }
});

app.listen(5000, (err, result) => {
  if (err) {
    console.log(err);
  }
  console.log("server is running in port 5000");
});
